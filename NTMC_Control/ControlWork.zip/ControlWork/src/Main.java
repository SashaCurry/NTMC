import javax.annotation.processing.SupportedSourceVersion;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        // task 1
//        System.out.println(new ContinuedFraction(157, 225));

        // task2
//        System.out.println(getDivisors(263));
//        System.out.println(new BigInteger("263").modPow(new BigInteger("1448"), new BigInteger("2897")));
//        task2(1052, 2897);

        // task3
        int[] xi = new int[]{5, 7, 3};
        int[] mi = new int[]{10, 13, 9};
//        new Congruence(xi, mi);

        // task4
//        System.out.println(new BigInteger("4").modInverse(new BigInteger("37")));
//        System.out.println(new BigInteger("3").modPow(new BigInteger("18"), new BigInteger("37")));
        //new GelfoldShenks(new BigInteger("3"), new BigInteger("1"), new BigInteger("37"));

        // task5
        BigInteger a = new BigInteger("2");
        BigInteger b = new BigInteger("15");
        BigInteger p = new BigInteger("37");
        new Task5(a, b, p);

//        System.out.println(new BigInteger("8").modInverse(p));
//        System.out.println(new BigInteger("9").multiply(new BigInteger("16").modInverse(p)).mod(p));
//        System.out.println(new BigInteger("63").mod(new BigInteger("37")));
//        System.out.println(new BigInteger("8").modPow(new BigInteger("2"), p));
        int[] xii = new int[]{3, 2};
        int[] mii = new int[]{4, 3};
//        new Congruence(xii, mii);
//        System.out.println("Проверка: " + a.modPow(new BigInteger("11"), p).equals(b));

        // task6
        int min = -3;
        int max = 3;
//        new Task6(min, max);
    }

    private static void task2(final int a, final int b) {
        ArrayList<Integer> bDivisors = getDivisors(b);
        System.out.printf("(%d/%d) = ", a, b);
        if (bDivisors.isEmpty()) {
            System.out.printf("делителей нет, число %d простое", b);
        }
        for (int div : bDivisors) {
            System.out.printf("(%d/%d) ", a, div);
        }
        for (int div : bDivisors) {
            System.out.printf("\n(%d/%d) = (%d/%d)", a, div, a % div, div);
        }
        System.out.println("\nПромежуточные результаты:");
        BigInteger aBig = new BigInteger(String.valueOf(a));
        for (int div : bDivisors) {
            System.out.println(new LegendreJacobi(aBig, new BigInteger(String.valueOf(div))));
        }
        System.out.print("Итог: " + new LegendreJacobi(aBig, new BigInteger(String.valueOf(b))));
    }

    private static ArrayList<Integer> getDivisors(int b) {
        ArrayList<Integer> res = new ArrayList<>();
        for (int i = 2; i <= b / 2; ++i) {
            BigInteger iBig = new BigInteger(String.valueOf(i));
            BigInteger bCopy = new BigInteger(String.valueOf(b));
            if (!iBig.isProbablePrime(20)) {
                continue;
            }
            while (bCopy.mod(iBig).equals(BigInteger.ZERO)) {
                res.add(i);
                bCopy = bCopy.divide(iBig);
            }
        }
        return res;
    }
}