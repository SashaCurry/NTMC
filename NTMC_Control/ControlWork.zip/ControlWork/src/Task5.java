import javax.annotation.processing.SupportedSourceVersion;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Task5 {
    private BigInteger a, b, p, order;
    private ArrayList<BigInteger> mi = new ArrayList<>();


    public Task5(BigInteger a, BigInteger b, BigInteger p) {
        this.a = a;
        this.b = b;
        this.p = p;
        task5();
    }

    private void task5() {
        BigInteger pMin1 = p.subtract(BigInteger.ONE);
        System.out.println("p = " + p);
        System.out.print("p - 1 = " + pMin1 + " = ");
        ArrayList<BigInteger> divisors = getDivisors(pMin1);
        Set<BigInteger> divs = new HashSet<>(divisors);
        boolean fl = false;
        for (BigInteger div : divs) {
            if (div.isProbablePrime(20)) {
                if (fl) {
                    System.out.print(" * ");
                }
                int cnt = divisors.lastIndexOf(div) - divisors.indexOf(div) + 1;
                mi.add(div.pow(cnt));
                System.out.print(div + "^" + cnt);
                fl = true;
            }
        }
        System.out.println();
        BigInteger order;
        for (BigInteger div : divs) {
            boolean isOrd = true;
            order = div;
            for (BigInteger div1 : divs) {
                if (div1.isProbablePrime(20)) {
                    BigInteger test = div.modPow(pMin1.divide(div1), p);
                    if (test.equals(BigInteger.ONE)) {
                        System.out.printf("%d не является образующим, так как %d^(%d/%d) %% %d = 1\n", div, div, pMin1, div1, p);
                        isOrd = false;
                        break;
                    }
                    System.out.printf("%d^(%d/%d) = %d^%d = %d != 1 (mod %d)\n", div, pMin1, div1, div, pMin1.divide(div1), test, p);
                }
            }
            if (isOrd) {
                System.out.printf("""
                        => a = %d - образующий.
                        Z*%d = 〈%d〉.
                        |Z*%d| = %d = %d * %d
                        """, order, p, order, p, pMin1, mi.get(0), mi.get(1));
                this.order = order;
                break;
            }
        }
        System.out.printf("Z*%d содержит подгруппы Gi = 〈ai〉 порядка %d и %d для a1 = %d^%d, a2 = %d^%d\n", p, mi.get(0), mi.get(1), this.order, mi.get(1), this.order, mi.get(0));
        System.out.printf("""
                При этом x ≡ x1 (mod %d)
                         x ≡ x2 (mod %d),
                где x1, x2:
                         (%d^%d)^x1 = %d^%d (mod %d)
                         (%d^%d)^x1 = %d^%d (mod %d) <=>
                """, mi.get(0), mi.get(1), this.order, mi.get(1), b, mi.get(1), p, this.order, mi.get(0), b, mi.get(0), p);
        System.out.printf("""
                             <=> %d^x1 = %d (mod %d)
                                 %d^x2 = %d (mod %d)
                        Решим систему.
                        Найдем x1... дальше самостоятельно
                        ...
                        """
                , this.order.modPow(mi.get(1), p), this.b.modPow(mi.get(1), p), p
                , this.order.modPow(mi.get(0), p), this.b.modPow(mi.get(0), p), p);
    }

    private static ArrayList<BigInteger> getDivisors(BigInteger b) {
        ArrayList<BigInteger> res = new ArrayList<>();
        for (BigInteger i = new BigInteger("2"); i.compareTo(b.divide(BigInteger.TWO)) <= 0; i = i.add(BigInteger.ONE)) {
            BigInteger bCopy = b;
            while (bCopy.mod(i).equals(BigInteger.ZERO)) {
                res.add(i);
                bCopy = bCopy.divide(i);
            }
        }
        return res;
    }
}
