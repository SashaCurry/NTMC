import javax.annotation.processing.SupportedSourceVersion;
import java.math.BigInteger;
import java.sql.Struct;
import java.util.*;

class Pair implements Comparable<Pair> {
    public int k;
    public BigInteger ak;

    public Pair(int k, BigInteger ak) {
        this.k = k;
        this.ak = ak;
    }

    @Override
    public String toString() {
        return "(" + k + ", " + ak + ")";
    }

    @Override
    public int compareTo(Pair b) {
        return this.ak.compareTo(b.ak);
    }
}

public class GelfoldShenks {
    public static BigInteger log(BigInteger a, BigInteger b, BigInteger p) {
        int r = (int) Math.sqrt(p.intValue() - 1) + 1;
        System.out.printf("""
                Шаг 1. B = |Z%d| = %d, r = [sqrt(B)] + 1 = %d.
                       a = %d,\s""", p, p.subtract(BigInteger.ONE), r, a);
        ArrayList<Pair> pairs = new ArrayList<>();
        BigInteger a0 = a;
        pairs.add(new Pair(1, a0));
        for (int k = 2; k < r; k++) {
            a0 = a0.multiply(a).mod(p);
            pairs.add(new Pair(k, a0));
            System.out.print("a^" + k + " = " + a0 + (k != r - 1 ? ", " : ".\n"));
        }
        pairs.sort(Pair::compareTo);
        System.out.println("       Упорядочиваем по 2й координате: " + pairs + ".");

        BigInteger a1 = a.pow(r).modInverse(p);
        System.out.printf("""
                Шаг 2. Для элемента а1 = a^-%d = (%d^%d)^-1 = %d^-1 = %d вычисляем a1^i (0 <= i <= r-1) и проверяем, является ли
                       a1^i * b = a1^i * 1 = a1^i второй координатой какой-либо пары выше:
                """, r, a, r, a.pow(r).mod(p), a1);
        BigInteger a1i = BigInteger.ONE;
        for (int i = 0; i < r; i++) {
            BigInteger tmp = a1i.multiply(b).mod(p);
            System.out.printf("       a1^%d = %d", i, a1i);
            for (Pair pair : pairs) {
                if (tmp.compareTo(pair.ak) == 0) {
                    BigInteger kri = BigInteger.valueOf(pair.k).add(BigInteger.valueOf(r).multiply(BigInteger.valueOf(i)));
                    System.out.printf(" = a^%d. => k = %d, i = %d.\n       => k + ri = %d + %d*%d = %d = log%d(1) = ord(%d).\n",
                            pair.k, pair.k, i, pair.k, r, i, kri, a, a);
                    return kri;
                }
            }
            System.out.println(",");
            a1i = a1i.multiply(a1).mod(p);
        }
        return null;
    }

    public GelfoldShenks(BigInteger a, BigInteger b, BigInteger p) {
        System.out.printf("Решим %d^x = 1 методом Гельфонда-Шенкса и найдем x = log%d(1), где x = {1..%d}.\n", a, a, p.subtract(BigInteger.ONE));
        BigInteger logResult = log(a, b, p);
        if (logResult == null) {
            System.out.println("Не удалось вычислить логарифм");
        } else {
            System.out.println("Результат: " + logResult);
            System.out.println("Проверка результата: " + a.modPow(logResult, p) + " = " + b.toString());
        }
    }
}
