import java.math.BigInteger;
import java.util.Scanner;

public class LegendreJacobi {
    public BigInteger a, p;
    public int value;
    private static final BigInteger oneNegate = BigInteger.ONE.negate();
    //private static BigInteger TWO = BigInteger.valueOf(2);
    private static final BigInteger eight = BigInteger.valueOf(8);

    public LegendreJacobi(BigInteger a, BigInteger p) {
        this.a = new BigInteger(a.toString());
        this.p = new BigInteger(p.toString());
        this.value = 1;
        if (this.a.compareTo(BigInteger.ZERO) < 0) {
            this.a = this.a.negate();
            this.value *= oneNegate.pow(this.p.subtract(BigInteger.ONE).divide(BigInteger.TWO).mod(BigInteger.TWO).intValue()).intValue();
        }
        if (this.a.gcd(this.p).compareTo(BigInteger.ONE) != 0) {
            this.value = 0;
            return;
        }
        this.a = this.a.mod(this.p);
        while (this.a.compareTo(BigInteger.ONE) != 0) {
            if (this.a.mod(BigInteger.TWO).equals(BigInteger.ZERO)) {
                long t = 0;
                while (this.a.mod(BigInteger.TWO).compareTo(BigInteger.ZERO) == 0) {
                    this.a = this.a.divide(BigInteger.TWO);
                    t++;
                }
                if (t % 2 != 0) {
                    this.value *= oneNegate.pow(this.p.pow(2).subtract(BigInteger.ONE).divide(eight).mod(BigInteger.TWO).intValue()).intValue();
                }
                continue;
            }
            int tmp = this.a.subtract(BigInteger.ONE).divide(BigInteger.TWO).mod(BigInteger.TWO).intValue() * this.p.subtract(BigInteger.ONE).divide(BigInteger.TWO).mod(BigInteger.TWO).intValue();
            this.value *= oneNegate.pow(tmp).intValue();
            BigInteger tmpBig = this.p;
            this.p = this.a;
            this.a = tmpBig;
            this.a = this.a.mod(this.p);
        }
        this.a = new BigInteger(a.toString());
        this.p = new BigInteger(p.toString());
    }

    public String toString() {
        return "(" + a + "/" + p + ") = " + value;
    }

    public static void runSymbol() {
        Scanner in = new Scanner(System.in);
        System.out.print("Введите a: ");
        BigInteger a = in.nextBigInteger();
        System.out.print("Введите p: ");
        BigInteger p = in.nextBigInteger();
        if (p.mod(BigInteger.TWO).equals(BigInteger.ZERO)){
            System.out.println("Число p должно быть нечетным!");
            return;
        }
        LegendreJacobi d = new LegendreJacobi(a, p);
        System.out.println("Результат: " + d);
    }
}
