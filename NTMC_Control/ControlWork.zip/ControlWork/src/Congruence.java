import javax.annotation.processing.SupportedSourceVersion;
import java.util.ArrayList;

public class Congruence {
    private int[] xi, mi;
    private int M = 1;

    public Congruence(int[] xi, int[] mi) {
        this.xi = xi;
        this.mi = mi;
        for (int m : mi) {
            this.M *= m;
        }
        System.out.print("M = ");
        for (int i = 0; i < mi.length; ++i) {
            if (i != mi.length - 1) {
                System.out.print(mi[i] + " * ");
            } else {
                System.out.println(mi[i] + " = " + this.M);
            }
        }
        solve();
    }

    private void solve() {
        int[] Mi = new int[mi.length];
        for (int i = 0; i < mi.length; ++i) {
            Mi[i] = M / mi[i];
            System.out.printf("M%d = %d / %d = %d\n", i + 1, M, mi[i], Mi[i]);
        }
        ArrayList<Integer> zi = new ArrayList<>();
        for (int i = 0; i < Mi.length; ++i) {
            int z = 1;
            for (; ; ++z) {
                if (Mi[i] * z % mi[i] == xi[i]) {
                    break;
                }
            }
            zi.add(z);
            System.out.printf("%dx ≡ %d (mod %d) => z%d = %d\n", Mi[i], xi[i], mi[i], i + 1, z);
        }
        long x = 0;
        for (int i = 0; i < zi.size(); ++i) {
            x += (long) zi.get(i) * Mi[i] % M;
            x %= M;
        }
        System.out.print("x = (");
        for (int i = 0; i < zi.size(); ++i) {
            System.out.printf("%d*%d" + ((i != zi.size() - 1) ? " + " : ") (mod " + M + ") = ("), zi.get(i), Mi[i]);
        }
        for (int i = 0; i < zi.size(); ++i) {
            System.out.printf("%d" + ((i != zi.size() - 1) ? " + " : ") (mod " + M + ") = "), zi.get(i) * Mi[i]);
        }
        System.out.println(x);
    }
}
