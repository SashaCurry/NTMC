import javax.management.MBeanServerInvocationHandler;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Task6 {
    private BigInteger p, min, max;
    private ArrayList<Point> points = new ArrayList<>();
    private Map<BigInteger, BigInteger> mapField = new HashMap<>();
    private ArrayList<BigInteger> X, X2, curve, Y;

    //private p;

    public Task6(int min, int max) {
        this.min = new BigInteger(String.valueOf(min));
        this.max = new BigInteger(String.valueOf(max));
        this.p = new BigInteger(String.valueOf(max - min + 1));
        X = new ArrayList<>();
        for (int i = min; i <= max; ++i) {
            X.add(new BigInteger(String.valueOf(i)));
        }
        BigInteger curElement;
        for (BigInteger i = BigInteger.ZERO; i.compareTo(p) < 0; i = i.add(BigInteger.ONE)) {
            if (i.compareTo(this.max) > 0) {
                curElement = i.subtract(p);
            } else {
                curElement = i;
            }
            mapField.put(i, curElement);
        }
        calculateTables();
        fillPoints();
        calculateOrder();
    }

    private void calculateTables() {
        X2 = new ArrayList<>();
        curve = new ArrayList<>();
        Y = new ArrayList<>();
        for (BigInteger x : X) {
//            X2.add(mapField.get(x.multiply(x).mod(p)));
            BigInteger x2 = x.multiply(x).mod(p);
            X2.add(x2);
            BigInteger x3 = x2.multiply(x).mod(p);
//            curve.add(mapField.get(x3.add(x).add(BigInteger.ONE).mod(p)));
            BigInteger x3res = x3.add(x).add(BigInteger.ONE);
            if (x3res.compareTo(BigInteger.ZERO) > 0) {
                x3res = x3res.mod(p);
            }
            while (x3res.add(p).compareTo(BigInteger.ZERO) < 0) {
                x3res = x3res.add(p);
            }
            curve.add(x3res);
            x3res = mapField.get(x3res.mod(p));
            int ySize = Y.size();
            for (BigInteger y = BigInteger.ZERO; y.compareTo(max) <= 0; y = y.add(BigInteger.ONE)) {
                if (mapField.get(y.multiply(y).mod(p)).equals(x3res)) {
                    Y.add(mapField.get(y));
                    break;
                }
            }
            if (ySize == Y.size()) {
                Y.add(null);
            }
        }
        System.out.println("X:           " + X);
        System.out.println("X^2:         " + X2);
        System.out.println("X^3 + X + 1: " + curve);
        System.out.println("Y:           " + Y + " (не забыть ± у ненулевых коэффициентов)");
    }

    private void fillPoints() {
        points.add(null);
        for (int i = 0; i < X.size(); ++i) {
            if (Y.get(i) == null) {
                continue;
            }
            if (Y.get(i).equals(BigInteger.ZERO)) {
                points.add(new Point(X.get(i), BigInteger.ZERO));
            } else {
                points.add(new Point(X.get(i), Y.get(i).negate()));
                points.add(new Point(X.get(i), Y.get(i)));
            }
        }
        System.out.println("Точки кривой: " + points);
        System.out.println("Всего точек: " + points.size());
    }

    private void calculateOrder() {
        for (Point p : points) {
            if (p == null) {
                continue;
            }
            Point curP = p;
            System.out.println("\nP = " + curP);
            int order = 1;
            while (curP != null) {
                curP = sum(curP, p);
                ++order;
            }
            System.out.println(order + "P = null.");
            System.out.println("Порядок точки P: " + order + "\n");
        }
    }

    private Point sum(Point curP, Point p) {
        System.out.println("Складываем: " + curP + " + " + p);
        BigInteger x1 = curP.x;
        BigInteger y1 = curP.y;
        BigInteger x2 = p.x;
        BigInteger y2 = p.y;
        BigInteger alpha;
        if (x1.equals(x2) && y1.equals(y2)) {
            try {
                alpha = (new BigInteger("3").multiply(x1.pow(2)).add(new BigInteger("1"))).multiply((BigInteger.TWO.multiply(y1)).modInverse(this.p)).mod(this.p);
                BigInteger ch = new BigInteger("3").multiply(x1.pow(2)).add(new BigInteger("1")).mod(this.p);
                BigInteger zn = (BigInteger.TWO.multiply(y1)).modInverse(this.p);
                System.out.printf("""
                        lambda = (3x1^2 + a)/2y1 = (3 * %d^2 + 5)/(2 * %d) = %d * %d = %d (mod %d)
                        """, x1, y1, ch, zn, alpha, this.p);
            } catch (Exception e) {
//                BigInteger ch = new BigInteger("3").multiply(x1.pow(2)).add(new BigInteger("1")).mod(this.p);
//                BigInteger zn = (BigInteger.TWO.multiply(y1)).mod(this.p);
//                System.out.printf("""
//                        lambda = (3x1^2 + a)/2y1
//                        Числитель = %d
//                        Знаменатель = %d\n""", ch, zn);
                return null;
            }
        } else {
            try {
                alpha = (y2.subtract(y1)).multiply((x2.subtract(x1)).modInverse(this.p)).mod(this.p);
                BigInteger ch = y2.subtract(y1).mod(this.p);
                BigInteger zn = x2.subtract(x1).modInverse(this.p);
                System.out.printf("""
                        lambda = (y2-y1)/(x2-x1) = (%d - %d)/(%d - %d) = %d * %d = %d (mod %d)
                        """, y2, y1, x2, x1, ch, zn, alpha, this.p);
            } catch (Exception e) {
//                BigInteger ch = y2.subtract(y1).mod(this.p);
//                BigInteger zn = x2.subtract(x1).mod(this.p);
//                System.out.printf("""
//                        lambda = (y2-y1)/(x2-x1)
//                        Числитель = %d
//                        Знаменатель = %d\n""", ch, zn);
                return null;
            }
        }
        BigInteger x3 = alpha.pow(2).subtract(x1).subtract(x2).mod(this.p);
        BigInteger y3 = alpha.multiply(x1.subtract(x3)).subtract(y1).mod(this.p);
        BigInteger x3Old = x3;
        System.out.printf("""
                x3 = lambda^2 - x1 - x2 = %d^2 - %d - %d = %d""", alpha, x1, x2, x3);
        if (x3.compareTo(max) > 0) {
            x3 = x3.subtract(this.p);
            System.out.println(" = " + x3 + " (mod " + this.p + ")");
        } else {
            System.out.println(" (mod " + this.p + ")");
        }
        System.out.printf("""
                y3 = lambda(x1 - x3) - y1 = %d(%d - %d) - %d = %d""",alpha, x1, x3Old, y1, y3);
        if (y3.compareTo(max) > 0) {
            y3 = y3.subtract(this.p);
            System.out.println(" = " + y3 + " (mod " + this.p + ")");
        } else {
            System.out.println(" (mod " + this.p + ")");
        }
        return new Point(x3, y3);
    }

    private ArrayList<BigInteger> squareRoot(BigInteger y2) {
        ArrayList<BigInteger> res = new ArrayList<>();
        for (BigInteger i = BigInteger.ZERO; i.compareTo(this.p) < 0; i = i.add(BigInteger.ONE)) {
            if (i.pow(2).mod(this.p).equals(y2)) {
                res.add(i);
            }
        }
        return res;
    }
}
