import java.util.ArrayList;
import java.util.Scanner;

public class ContinuedFraction {
    public ArrayList<Integer> P;
    public ArrayList<Integer> Q;
    public ArrayList<Integer> q;
    public int a, b;
    public int gcd;

    public ContinuedFraction(int a, int b) {
        this.a = a;
        this.b = b;
        this.P = new ArrayList<>();
        this.P.add(0);
        this.P.add(1);
        this.Q = new ArrayList<>();
        this.Q.add(1);
        this.Q.add(0);
        this.q = new ArrayList<>();
        int tmp, q;
        int i = 1;
        System.out.printf("a0 = %d, a1 = %d\n", a, b);
        while (b != 0) {
            q = a / b;
            System.out.printf("a%d = %d = %d * %d + %d = a%d * q%d + a%d\n",
                    i - 1, a, b, q, a % b, i, i, i + 1);
            this.q.add(q);
            this.P.add(q * this.P.get(this.P.size() - 1) + this.P.get(this.P.size() - 2));
            this.Q.add(q * this.Q.get(this.Q.size() - 1) + this.Q.get(this.Q.size() - 2));
            tmp = a;
            a = b;
            b = tmp % b;
            ++i;
        }
        this.gcd = a;
    }

    private static String formatMasAnswer(String objName, ArrayList<Integer> e) {
        String answer = objName + " = [";
        ArrayList<String> mas = new ArrayList<>();
        for (int i : e) {
            mas.add(String.valueOf(i));
        }
        answer += String.join(", ", mas) + "]\n";
        return answer;
    }

    public String toString() {
        String answer = "";
        answer += formatMasAnswer(this.a + "/" + this.b, this.q);
        answer += ("Выпишем подходящие дроби:\n(самостоятельная часть)\n");
//        answer += formatMasAnswer("P", this.P);
//        answer += formatMasAnswer("Q", this.Q);
        return answer;
    }

    public static void runFraction() {
        Scanner in = new Scanner(System.in);
        System.out.print("Введите a: ");
        int a = in.nextInt();
        System.out.print("Введите b: ");
        int b = in.nextInt();
        System.out.println(new ContinuedFraction(a, b));
    }
}
